import React from 'react';
import { render } from 'react-dom';
import App from './app.component';

render(
  <App />,
  document.getElementById('oc-examples'),
);
